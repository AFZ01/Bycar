from django.urls import path
from . import views
#http://127.0.0.1:8000/kariyer
#http://127.0.0.1:8000/login
#http://127.0.0.1:8000/home

urlpatterns=[
    path("",views.anasayfa),
    path("home",views.anasayfa),
    path("kariyer",views.kariyer),
]