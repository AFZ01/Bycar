from django.shortcuts import render

alan_list=["Gömülü Yazılımlar","Görüntü İşleme","Web Geliştirme","Python"]
pozisyon_list=[
        {
        "alan": "stajer",
        "bölüm": "Bilgisayar yada Yazılım",
        "dil": "Python",
        "şartlar": "python da daha önce proje yapmış olması gerekmektedir.",
        "alan_resmi": "https://picsum.photos/200/300?random=1",
        "anasayfa":True
    },
        {
        "alan": "junior",
        "bölüm": "Bilgisayar yada Yazılım",
        "dil": "Python",
        "şartlar": "python da daha önce proje yapmış olması gerekmektedir.",
        "alan_resmi": "https://picsum.photos/200/300?random=2",
        "anasayfa":True
    },
        {
        "alan": "senior",
        "bölüm": "Bilgisayar yada Yazılım",
        "dil":"Python",
        "şartlar":"python da daha önce proje yapmış olması gerekmektedir.",
        "alan_resmi":"https://picsum.photos/200/300?random=3",
        "anasayfa":False
    },
        {
        "alan": "uzman",
        "bölüm":"Bilgisayar yada Yazılım",
        "dil": "Python",
        "şartlar": "python da daha önce proje yapmış olması gerekmektedir.",
        "alan_resmi": "https://picsum.photos/200/300?random=4",
        "anasayfa":False
    }

    ]

def anasayfa(request):
    data={
        "alanlar":alan_list,
        "pozisyonlar":pozisyon_list,
    }
    return render(request,"index.html", data)
def kariyer(request):
    data={
        "alanlar":alan_list,
        "pozisyonlar":pozisyon_list,
    }
    return render(request,"kariyer.html",data)
