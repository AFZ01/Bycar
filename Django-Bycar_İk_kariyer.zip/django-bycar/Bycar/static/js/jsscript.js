var i 
var images =["{% static 'img/vekt1' %}","{% static 'img/vekt2' %}","{% static 'img/vekt3' %}" ]

var duration = 2000;

function SildeImg(){
    document.slide.src=images[1];

    if (i<images.length -1) {
        i++;
    } else{
        i=0;
    }
    setTimeout("slideImg()",duration);

}

window.onload = SildeImg;